package com.mainproject.user.service;

public interface UserService {

}
