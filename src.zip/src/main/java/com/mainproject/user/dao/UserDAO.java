package com.mainproject.user.dao;

public interface UserDAO {

}
