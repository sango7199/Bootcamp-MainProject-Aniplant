package com.mainproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AniplantApplicationTests {

	@Test
	void contextLoads() {
	}

}
